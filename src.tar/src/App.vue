<template>
  <div class="min-h-screen flex flex-col">
    <header class="py-4 md:py-6 border-b border-gray-100 dark:border-gray-800 transition-colors">
      <div class="max-w-[90%] mx-auto px-4 sm:px-8 h-16 flex justify-between items-center">
        <router-link to="/" class="text-lg md:text-xl font-bold tracking-wider text-gray-800 dark:text-gray-100 transition-colors">
          MY BLOG
        </router-link>
        
        <div class="flex items-center space-x-4 md:space-x-6">
          <nav class="space-x-4 md:space-x-6 text-sm md:text-base text-gray-500 dark:text-gray-400">
            <router-link to="/" class="hover:text-gray-900 dark:hover:text-white transition-colors">首页</router-link>
            <a href="#" class="hover:text-gray-900 dark:hover:text-white transition-colors">关于</a>
          </nav>
          
          <div class="w-px h-4 bg-gray-300 dark:bg-gray-600"></div>

          <button @click="toggleDark" class="text-xl focus:outline-none" title="切换主题">
            {{ isDark ? '🌙' : '☀️' }}
          </button>
        </div>
      </div>
    </header>

    <main class="flex-grow max-w-3xl mx-auto w-full px-4 sm:px-6 py-8 md:py-12">
      <router-view />
    </main>

    <footer class="py-6 md:py-8 text-center text-xs md:text-sm text-gray-400 dark:text-gray-500">
      <p>© 2026 My Minimalist Blog. All rights reserved.</p>
    </footer>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';

const isDark = ref(false);
// 切换主题
const toggleDark = () => {
  isDark.value = !isDark.value;
  // 获取HTML标签
  const htmlEl = document.documentElement;

  if(isDark.value) {
    htmlEl.classList.add('dark');
    localStorage.setItem('theme', 'dark');
  } else {
    htmlEl.classList.remove('dark');
    localStorage.setItem('theme', 'light');
  }

}

// 组件挂载时检查用户之前的主题选择
onMounted(() => {
  const savedTheme = localStorage.getItem('theme')
  if(savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    isDark.value = true;
    document.documentElement.classList.add('dark');
  }
}) 

</script>