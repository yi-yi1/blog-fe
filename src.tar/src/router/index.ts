import { createRouter, createWebHistory } from 'vue-router'

// 定义路由规则
const routes = [
    {
        path: '/',
        name: 'Home',
        // 懒加载
        component: () => import('../views/Home.vue'),
    },
    {
        path: '/post/:id', // :id 是动态参数，代表文章的唯一标识
        name: 'Post',
        // 懒加载文章详情页组件
        component: () => import('../views/Post.vue')
    }
]

const router = createRouter({
    // 使用html5的历史记录模式，这样URL中就不会有#号
    history: createWebHistory(),
    routes,
})

export default router