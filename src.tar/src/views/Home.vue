<template>
    <div class="space-y-8 md:space-y-12"><article
        v-for="post in posts"
        :key="post.id"
        class="group cursor-pointer"
        @click="goToPost(post.id)"
        >
        <time class="text-xs md:text-sm text-gray-400 mb-1 md:mb-2 block font-mono">
            {{ post.date }}
        </time>

        <h2 class="text-xl md:text-2xl font-semibold text-gray-800 mb-2 md:mb-3 group-hover:text-blue-600 transition-colors dark:text-gray-100">
            {{ post.title }}
        </h2>

        <p class="text-sm md:text-base text-gray-600 leading-relaxed line-clamp-2 md:line-clamp-none">
            {{ post.excerpt }}
        </p>
        </article>
    </div>
</template>

<script setup lang="ts">
import {ref} from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

// 模拟的博客文章数据
const posts = ref([
  {
    id: 1,
    title: 'Vue 3 组合式 API 的优雅实践',
    date: '2026-02-14',
    excerpt: '相比于 Options API，Composition API 提供了更灵活的代码组织方式。本文记录了我在重构前端项目时的一些心得体会……'
  },
  {
    id: 2,
    title: '深入理解 Java 性能调优与 MySQL 索引优化',
    date: '2026-01-20',
    excerpt: '后端服务的响应速度直接影响用户体验。探讨如何通过优化数据库查询和 JVM 参数来提升系统整体吞吐量……'
  },
  {
    id: 3,
    title: '脉冲神经网络 (SNN) 与 DVS 数据处理入门',
    date: '2025-12-10',
    excerpt: '基于事件驱动的神经形态计算展现出了极低的功耗优势。本文简述了如何处理动态视觉传感器生成的数据流……'
  }
])
// 点击跳转到文章详情页
const goToPost = (id: number) => {
    router.push(`/post/${id}`);
}

</script>